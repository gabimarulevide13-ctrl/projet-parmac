
import { fetchPharmaciesNearby, filterPharmacies, searchPharmacies } from "./utils/pharmacyData.js";
import { getCurrentLocation } from "./utils/geolocation.js";

async function loadPharmacies() {
  try {
    const location = await getCurrentLocation();
    const pharmacies = await fetchPharmaciesNearby(location.latitude, location.longitude);
    displayPharmacies(pharmacies);
  } catch (error) {
    console.error("Erreur chargement pharmacies :", error);
  }
}

function displayPharmacies(pharmacies) {
  // TODO : remplacer par ton code d'affichage existant
  console.log("Pharmacies à afficher :", pharmacies);
}

loadPharmacies();
