function FilterPanel({ filters, onFiltersChange }) {
  try {
    const handleFilterChange = (key, value) => {
      onFiltersChange({
        ...filters,
        [key]: value
      });
    };

    return (
      <div className="card" data-name="filter-panel" data-file="components/FilterPanel.js">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-[var(--accent-color)] to-[var(--primary-color)] rounded-2xl flex items-center justify-center">
            <div className="icon-filter text-white text-lg"></div>
          </div>
          <div>
            <h3 className="text-xl font-bold text-[var(--text-primary)]">Filtres</h3>
            <p className="text-sm text-[var(--text-secondary)]">Affinez votre recherche</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-4">
            <div className="bg-[var(--background-color)] p-4 rounded-2xl">
              <label className="flex items-center space-x-4 cursor-pointer">
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={filters.open24h}
                    onChange={(e) => handleFilterChange('open24h', e.target.checked)}
                    className="w-5 h-5 text-[var(--primary-color)] border-2 border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:ring-opacity-50"
                  />
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-xl flex items-center justify-center">
                    <div className="icon-clock text-green-600 text-sm"></div>
                  </div>
                  <span className="font-semibold text-[var(--text-primary)]">Ouvert 24h/24</span>
                </div>
              </label>
            </div>

            <div className="bg-[var(--background-color)] p-4 rounded-2xl">
              <label className="flex items-center space-x-4 cursor-pointer">
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={filters.nightService}
                    onChange={(e) => handleFilterChange('nightService', e.target.checked)}
                    className="w-5 h-5 text-[var(--primary-color)] border-2 border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:ring-opacity-50"
                  />
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-xl flex items-center justify-center">
                    <div className="icon-moon text-blue-600 text-sm"></div>
                  </div>
                  <span className="font-semibold text-[var(--text-primary)]">Service de nuit</span>
                </div>
              </label>
            </div>

            <div className="bg-[var(--background-color)] p-4 rounded-2xl">
              <label className="flex items-center space-x-4 cursor-pointer">
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={filters.hasStock}
                    onChange={(e) => handleFilterChange('hasStock', e.target.checked)}
                    className="w-5 h-5 text-[var(--primary-color)] border-2 border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:ring-opacity-50"
                  />
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-xl flex items-center justify-center">
                    <div className="icon-package text-purple-600 text-sm"></div>
                  </div>
                  <span className="font-semibold text-[var(--text-primary)]">Stock disponible</span>
                </div>
              </label>
            </div>
          </div>

          <div className="bg-[var(--background-color)] p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-4">
              <label className="text-sm font-bold text-[var(--text-primary)] tracking-wide">
                RAYON DE RECHERCHE
              </label>
              <span className="bg-[var(--primary-color)] text-white px-3 py-1 rounded-xl text-sm font-bold">
                {filters.searchRadius} km
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="20"
              value={filters.searchRadius}
              onChange={(e) => handleFilterChange('searchRadius', parseInt(e.target.value))}
              className="w-full h-3 bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] rounded-full appearance-none cursor-pointer slider"
              style={{
                background: `linear-gradient(to right, var(--primary-color) 0%, var(--primary-color) ${(filters.searchRadius - 1) / 19 * 100}%, var(--border-color) ${(filters.searchRadius - 1) / 19 * 100}%, var(--border-color) 100%)`
              }}
            />
            <div className="flex justify-between text-xs text-[var(--text-secondary)] mt-2 font-medium">
              <span>1 km</span>
              <span>20 km</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => onFiltersChange({
                open24h: false,
                nightService: false,
                hasStock: false,
                searchRadius: 5
              })}
              className="w-full bg-red-50 text-red-600 border-2 border-red-200 px-6 py-4 rounded-2xl font-bold tracking-wide hover:bg-red-100 hover:border-red-300 transition-all duration-200 flex items-center justify-center space-x-2"
            >
              <div className="icon-x text-lg"></div>
              <span>RÉINITIALISER</span>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('FilterPanel component error:', error);
    return null;
  }
}
