function Header({ user, currentView, onViewChange, onLogout }) {
  try {
    return (
      <header className="navbar sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-3">
              <div className="icon-container">
                <div className="icon-cross text-white text-xl"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gradient">PharmaGuard</h1>
                <p className="text-xs text-[var(--text-secondary)] font-medium">Pharmacies de garde</p>
              </div>
            </div>
            
            <nav className="hidden md:flex space-x-2">
              <button
                onClick={() => onViewChange('map')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 flex items-center space-x-2 ${
                  currentView === 'map' 
                    ? 'bg-[var(--primary-color)] text-white shadow-md' 
                    : 'text-[var(--text-secondary)] hover:text-[var(--primary-color)] hover:bg-[var(--background-color)]'
                }`}
              >
                <div className="icon-map-pin text-lg"></div>
                <span>Carte</span>
              </button>
              <button
                onClick={() => onViewChange('list')}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 flex items-center space-x-2 ${
                  currentView === 'list' 
                    ? 'bg-[var(--primary-color)] text-white shadow-md' 
                    : 'text-[var(--text-secondary)] hover:text-[var(--primary-color)] hover:bg-[var(--background-color)]'
                }`}
              >
                <div className="icon-list text-lg"></div>
                <span>Liste</span>
              </button>
              {user.role === 'admin' && (
                <button
                  onClick={() => onViewChange('admin')}
                  className={`px-6 py-3 rounded-xl font-semibold transition-all duration-200 flex items-center space-x-2 ${
                    currentView === 'admin' 
                      ? 'bg-[var(--accent-color)] text-white shadow-md' 
                      : 'text-[var(--text-secondary)] hover:text-[var(--accent-color)] hover:bg-[var(--background-color)]'
                  }`}
                >
                  <div className="icon-settings text-lg"></div>
                  <span>Admin</span>
                </button>
              )}
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3 bg-[var(--background-color)] px-4 py-2 rounded-2xl">
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--accent-color)] to-[var(--primary-color)] rounded-xl flex items-center justify-center">
                <div className="icon-user text-white text-lg"></div>
              </div>
              <div>
                <span className="text-[var(--text-primary)] font-semibold text-sm">{user.name}</span>
                <p className="text-[var(--text-secondary)] text-xs">{user.role}</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="p-3 text-[var(--text-secondary)] hover:text-[var(--error-color)] hover:bg-red-50 rounded-xl transition-all duration-200"
              title="Se déconnecter"
            >
              <div className="icon-log-out text-xl"></div>
            </button>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}
