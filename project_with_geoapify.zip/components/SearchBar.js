function SearchBar({ onSearch }) {
  try {
    const [searchQuery, setSearchQuery] = React.useState('');

    const handleSearch = (e) => {
      e.preventDefault();
      onSearch(searchQuery);
    };

    const handleInputChange = (e) => {
      const value = e.target.value;
      setSearchQuery(value);
      
      // Recherche en temps réel après 2 caractères
      if (value.length >= 2) {
        onSearch(value);
      } else if (value.length === 0) {
        onSearch(''); // Réinitialiser la recherche
      }
    };

    return (
      <div className="card" data-name="search-bar" data-file="components/SearchBar.js">
        <form onSubmit={handleSearch} className="flex space-x-2">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <div className="icon-search text-[var(--text-secondary)]"></div>
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={handleInputChange}
              placeholder="Rechercher une pharmacie, une ville..."
              className="w-full pl-10 pr-4 py-3 border border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent outline-none"
            />
          </div>
          <button
            type="submit"
            className="btn-primary px-6"
          >
            <div className="icon-search text-lg"></div>
          </button>
        </form>
        
        {searchQuery && (
          <div className="mt-2 text-sm text-[var(--text-secondary)]">
            Recherche pour: "{searchQuery}"
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('SearchBar component error:', error);
    return null;
  }
}