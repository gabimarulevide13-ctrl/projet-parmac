function PharmacyTable({ pharmacies, setPharmacies }) {
  try {
    const [editingId, setEditingId] = React.useState(null);
    const [showAddForm, setShowAddForm] = React.useState(false);

    const handleEdit = (id) => {
      setEditingId(id);
    };

    const handleSave = (id) => {
      setEditingId(null);
      // Ici on sauvegarderait en base de données
    };

    const handleDelete = (id) => {
      if (confirm('Êtes-vous sûr de vouloir supprimer cette pharmacie ?')) {
        setPharmacies(pharmacies.filter(p => p.id !== id));
      }
    };

    return (
      <div className="card" data-name="pharmacy-table" data-file="components/PharmacyTable.js">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-[var(--text-primary)]">
            Gestion des Pharmacies
          </h2>
          <button 
            onClick={() => setShowAddForm(true)}
            className="btn-primary"
          >
            <div className="icon-plus inline mr-2"></div>
            Ajouter une pharmacie
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full table-auto">
            <thead>
              <tr className="border-b border-[var(--border-color)]">
                <th className="text-left py-3 px-4 font-medium text-[var(--text-primary)]">Nom</th>
                <th className="text-left py-3 px-4 font-medium text-[var(--text-primary)]">Adresse</th>
                <th className="text-left py-3 px-4 font-medium text-[var(--text-primary)]">Téléphone</th>
                <th className="text-left py-3 px-4 font-medium text-[var(--text-primary)]">Horaires</th>
                <th className="text-left py-3 px-4 font-medium text-[var(--text-primary)]">Statut</th>
                <th className="text-left py-3 px-4 font-medium text-[var(--text-primary)]">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pharmacies.map(pharmacy => (
                <tr key={pharmacy.id} className="border-b border-[var(--border-color)] hover:bg-[var(--secondary-color)]">
                  <td className="py-3 px-4">{pharmacy.name}</td>
                  <td className="py-3 px-4 text-sm text-[var(--text-secondary)]">
                    {pharmacy.address}, {pharmacy.district}
                  </td>
                  <td className="py-3 px-4">{pharmacy.phone}</td>
                  <td className="py-3 px-4">{pharmacy.hours}</td>
                  <td className="py-3 px-4">
                    <span className={pharmacy.isOpen ? 
                      'bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium' : 
                      'bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium'
                    }>
                      {pharmacy.isOpen ? 'Ouvert' : 'Fermé'}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleEdit(pharmacy.id)}
                        className="p-2 text-[var(--accent-color)] hover:bg-[var(--secondary-color)] rounded"
                      >
                        <div className="icon-edit text-sm"></div>
                      </button>
                      <button
                        onClick={() => handleDelete(pharmacy.id)}
                        className="p-2 text-[var(--error-color)] hover:bg-[var(--secondary-color)] rounded"
                      >
                        <div className="icon-trash text-sm"></div>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PharmacyTable component error:', error);
    return null;
  }
}