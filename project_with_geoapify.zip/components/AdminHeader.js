function AdminHeader() {
  try {
    return (
      <header className="bg-white shadow-sm border-b border-[var(--border-color)] px-6 py-4" data-name="admin-header" data-file="components/AdminHeader.js">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
              <div className="icon-cross text-white text-xl"></div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-[var(--text-primary)]">PharmaGuard Admin</h1>
              <p className="text-sm text-[var(--text-secondary)]">Tableau de bord</p>
            </div>
          </div>

          <nav className="flex items-center space-x-6">
            <a 
              href="index.html" 
              className="text-[var(--text-secondary)] hover:text-[var(--primary-color)] transition-colors"
            >
              <div className="icon-arrow-left inline mr-2"></div>
              Retour à l'app
            </a>
            
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-[var(--accent-color)] rounded-full flex items-center justify-center">
                <div className="icon-user text-white text-sm"></div>
              </div>
              <span className="text-[var(--text-primary)] font-medium">Administrateur</span>
            </div>
          </nav>
        </div>
      </header>
    );
  } catch (error) {
    console.error('AdminHeader component error:', error);
    return null;
  }
}