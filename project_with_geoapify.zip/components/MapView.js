function MapView({ pharmacies, userLocation }) {
  try {
    const mapRef = React.useRef(null);
    const [selectedPharmacy, setSelectedPharmacy] = React.useState(null);

    React.useEffect(() => {
      if (mapRef.current && userLocation) {
        initializeMap();
      }
    }, [userLocation, pharmacies]);

    const initializeMap = () => {
      const mapContainer = mapRef.current;
      mapContainer.innerHTML = '';

      const mapDiv = document.createElement('div');
      mapDiv.className = 'w-full h-96 bg-gradient-to-br from-[var(--background-color)] to-[var(--surface-color)] rounded-3xl border border-[var(--border-color)] flex items-center justify-center relative overflow-hidden';
      mapDiv.innerHTML = `
        <div class="absolute inset-0 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] opacity-5"></div>
        <div class="text-center relative z-10">
          <div class="w-20 h-20 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-3xl flex items-center justify-center mx-auto mb-4">
            <div class="icon-map text-3xl text-white"></div>
          </div>
          <h3 class="text-xl font-bold text-[var(--text-primary)] mb-2">Carte Interactive</h3>
          <p class="text-[var(--text-secondary)] font-medium">Google Maps API à intégrer</p>
          <div class="mt-4 bg-[var(--surface-color)] bg-opacity-80 px-4 py-2 rounded-xl inline-block">
            <p class="text-sm text-[var(--text-secondary)] font-medium">
              Position: ${userLocation ? `${userLocation.latitude.toFixed(4)}, ${userLocation.longitude.toFixed(4)}` : 'Non disponible'}
            </p>
          </div>
        </div>
      `;
      
      mapContainer.appendChild(mapDiv);
    };

    return (
      <div className="space-y-6" data-name="map-view" data-file="components/MapView.js">
        <div className="bg-[var(--surface-color)] rounded-3xl p-6 border border-[var(--border-color)] shadow-lg">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-2xl flex items-center justify-center">
                <div className="icon-map-pin text-white text-xl"></div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[var(--text-primary)]">
                  Pharmacies à proximité
                </h2>
                <p className="text-[var(--text-secondary)] font-medium">
                  {pharmacies.length} pharmacie{pharmacies.length !== 1 ? 's' : ''} trouvée{pharmacies.length !== 1 ? 's' : ''}
                </p>
              </div>
            </div>
            <div className="bg-[var(--primary-color)] bg-opacity-10 px-4 py-2 rounded-xl">
              <span className="text-[var(--primary-color)] font-bold text-lg">{pharmacies.length}</span>
            </div>
          </div>
        </div>

        <div ref={mapRef} className="w-full shadow-xl"></div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {pharmacies.slice(0, 4).map(pharmacy => (
            <PharmacyCard key={pharmacy.id} pharmacy={pharmacy} />
          ))}
        </div>

        {pharmacies.length > 4 && (
          <div className="text-center">
            <button className="bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] text-white px-8 py-4 rounded-2xl font-bold tracking-wide hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex items-center space-x-3 mx-auto">
              <div className="icon-eye text-lg"></div>
              <span>VOIR TOUTES LES PHARMACIES ({pharmacies.length})</span>
            </button>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('MapView component error:', error);
    return null;
  }
}
