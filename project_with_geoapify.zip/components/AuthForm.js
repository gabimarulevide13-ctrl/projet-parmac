function AuthForm({ onLogin }) {
  try {
    const [isLogin, setIsLogin] = React.useState(true);
    const [formData, setFormData] = React.useState({
      email: '',
      password: '',
      name: '',
      role: 'user'
    });
    const [loading, setLoading] = React.useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);
      
      try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        const userData = {
          id: Date.now(),
          name: formData.name || formData.email.split('@')[0],
          email: formData.email,
          role: formData.role
        };
        
        onLogin(userData);
      } catch (error) {
        console.error('Erreur d\'authentification:', error);
      } finally {
        setLoading(false);
      }
    };

    const handleInputChange = (e) => {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value
      });
    };

    return (
      <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-[var(--background-color)] via-[var(--surface-color)] to-[var(--background-color)]" data-name="auth-form" data-file="components/AuthForm.js">
        <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Illustration Section */}
          <div className="hidden lg:flex flex-col items-center justify-center space-y-8">
            <div className="relative">
              <div className="w-96 h-96 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-full opacity-10 absolute -top-8 -left-8"></div>
              <div className="w-80 h-80 bg-[var(--surface-color)] rounded-3xl shadow-2xl flex items-center justify-center relative z-10">
                <div className="text-center space-y-6">
                  <div className="w-32 h-32 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-3xl mx-auto flex items-center justify-center">
                    <div className="icon-heart-pulse text-white text-6xl"></div>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-[var(--text-primary)] mb-2">Soins de santé</h3>
                    <p className="text-[var(--text-secondary)]">Trouvez rapidement les pharmacies de garde près de chez vous</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--accent-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mb-3">
                  <div className="icon-map-pin text-[var(--accent-color)] text-2xl"></div>
                </div>
                <p className="text-sm text-[var(--text-secondary)] font-medium">Géolocalisation</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--success-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mb-3">
                  <div className="icon-clock text-[var(--success-color)] text-2xl"></div>
                </div>
                <p className="text-sm text-[var(--text-secondary)] font-medium">24h/24</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--warning-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mb-3">
                  <div className="icon-phone text-[var(--warning-color)] text-2xl"></div>
                </div>
                <p className="text-sm text-[var(--text-secondary)] font-medium">Contact direct</p>
              </div>
            </div>
          </div>

          {/* Form Section */}
          <div className="w-full max-w-md mx-auto lg:mx-0">
            <div className="text-center mb-8">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <div className="icon-container">
                  <div className="icon-cross text-white text-3xl"></div>
                </div>
                <div>
                  <h1 className="text-4xl font-bold text-gradient">PharmaGuard</h1>
                  <p className="text-[var(--text-secondary)] text-sm font-medium">Pharmacies de garde</p>
                </div>
              </div>
              <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-2">
                {isLogin ? 'Bon retour !' : 'Rejoignez-nous'}
              </h2>
              <p className="text-[var(--text-secondary)]">
                {isLogin ? 'Connectez-vous pour accéder aux pharmacies' : 'Créez votre compte en quelques secondes'}
              </p>
            </div>

            <form className="card space-y-6" onSubmit={handleSubmit}>
              {!isLogin && (
                <div>
                  <label className="block text-sm font-semibold text-[var(--text-primary)] mb-3">
                    Nom complet
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Entrez votre nom complet"
                    className="input-field"
                    required={!isLogin}
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold text-[var(--text-primary)] mb-3">
                  Adresse email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="votre@email.com"
                  className="input-field"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[var(--text-primary)] mb-3">
                  Mot de passe
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="••••••••"
                  className="input-field"
                  required
                />
              </div>

              {!isLogin && (
                <div>
                  <label className="block text-sm font-semibold text-[var(--text-primary)] mb-3">
                    Type de compte
                  </label>
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleInputChange}
                    className="input-field"
                  >
                    <option value="user">Utilisateur</option>
                    <option value="pharmacien">Pharmacien</option>
                    <option value="admin">Administrateur</option>
                  </select>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="flex items-center justify-center space-x-3">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                    <span>Connexion en cours...</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center space-x-2">
                    <span>{isLogin ? 'Se connecter' : 'Créer mon compte'}</span>
                    <div className="icon-arrow-right text-lg"></div>
                  </div>
                )}
              </button>

              <div className="text-center pt-4">
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-[var(--accent-color)] hover:text-[var(--primary-color)] font-medium transition-colors duration-200"
                >
                  {isLogin 
                    ? "Pas encore de compte ? Inscrivez-vous" 
                    : "Déjà inscrit ? Connectez-vous"
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AuthForm component error:', error);
    return null;
  }
}
