function PharmacyCard({ pharmacy }) {
  try {
    const isOpen = pharmacy.isOpen;
    const distance = pharmacy.distance ? `${pharmacy.distance.toFixed(1)} km` : 'Distance inconnue';

    const handleCall = () => {
      window.open(`tel:${pharmacy.phone}`, '_self');
    };

    const handleDirections = () => {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${pharmacy.latitude},${pharmacy.longitude}`;
      window.open(url, '_blank');
    };

    return (
      <div className="pharmacy-card group" data-name="pharmacy-card" data-file="components/PharmacyCard.js">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-start space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-2xl flex items-center justify-center flex-shrink-0">
              <div className="icon-cross text-white text-xl"></div>
            </div>
            <div>
              <h3 className="font-bold text-[var(--text-primary)] text-lg leading-tight">{pharmacy.name}</h3>
              <p className="text-[var(--text-secondary)] text-sm font-medium">{pharmacy.city}, {pharmacy.district}</p>
            </div>
          </div>
          <div className={`px-3 py-1.5 rounded-full text-xs font-bold tracking-wide ${
            isOpen 
              ? 'bg-green-50 text-green-700 border border-green-200' 
              : 'bg-red-50 text-red-700 border border-red-200'
          }`}>
            {isOpen ? 'OUVERT' : 'FERMÉ'}
          </div>
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center text-[var(--text-secondary)]">
            <div className="w-5 h-5 bg-blue-50 rounded-lg flex items-center justify-center mr-3">
              <div className="icon-map-pin text-blue-600 text-sm"></div>
            </div>
            <span className="text-sm font-medium">{pharmacy.address}</span>
          </div>
          
          <div className="flex items-center text-[var(--text-secondary)]">
            <div className="w-5 h-5 bg-green-50 rounded-lg flex items-center justify-center mr-3">
              <div className="icon-phone text-green-600 text-sm"></div>
            </div>
            <span className="text-sm font-medium">{pharmacy.phone}</span>
          </div>
          
          <div className="flex items-center text-[var(--text-secondary)]">
            <div className="w-5 h-5 bg-purple-50 rounded-lg flex items-center justify-center mr-3">
              <div className="icon-navigation text-purple-600 text-sm"></div>
            </div>
            <span className="text-sm font-medium">{distance}</span>
          </div>
          
          <div className="flex items-center text-[var(--text-secondary)]">
            <div className="w-5 h-5 bg-orange-50 rounded-lg flex items-center justify-center mr-3">
              <div className="icon-clock text-orange-600 text-sm"></div>
            </div>
            <span className="text-sm font-medium">{pharmacy.hours}</span>
          </div>
        </div>

        {pharmacy.services && pharmacy.services.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-bold text-[var(--text-primary)] mb-3 tracking-wide">SERVICES DISPONIBLES</h4>
            <div className="flex flex-wrap gap-2">
              {pharmacy.services.map((service, index) => (
                <span 
                  key={index}
                  className="bg-[var(--primary-color)] bg-opacity-10 text-[var(--primary-color)] px-3 py-1.5 rounded-xl text-xs font-semibold tracking-wide"
                >
                  {service}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="flex space-x-3">
          <button
            onClick={handleCall}
            className="flex-1 bg-[var(--accent-color)] text-white px-4 py-3 rounded-xl text-sm font-bold tracking-wide hover:bg-opacity-90 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <div className="icon-phone text-sm"></div>
            <span>APPELER</span>
          </button>
          <button
            onClick={handleDirections}
            className="flex-1 bg-[var(--surface-color)] text-[var(--primary-color)] border-2 border-[var(--primary-color)] px-4 py-3 rounded-xl text-sm font-bold tracking-wide hover:bg-[var(--primary-color)] hover:text-white hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <div className="icon-navigation text-sm"></div>
            <span>ITINÉRAIRE</span>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PharmacyCard component error:', error);
    return null;
  }
}
