// Simulation d'une API d'authentification
const AuthAPI = {
  login: async (email, password) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulation d'une vérification d'authentification
        if (email && password) {
          resolve({
            id: Date.now(),
            name: email.split('@')[0],
            email: email,
            role: email.includes('admin') ? 'admin' : 'user',
            token: 'mock-jwt-token-' + Date.now()
          });
        } else {
          reject(new Error('Identifiants invalides'));
        }
      }, 1000);
    });
  },

  register: async (userData) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (userData.email && userData.password && userData.name) {
          resolve({
            id: Date.now(),
            name: userData.name,
            email: userData.email,
            role: userData.role || 'user',
            token: 'mock-jwt-token-' + Date.now()
          });
        } else {
          reject(new Error('Données incomplètes'));
        }
      }, 1000);
    });
  },

  logout: () => {
    localStorage.removeItem('pharmaGuardUser');
    localStorage.removeItem('pharmaGuardToken');
  },

  getCurrentUser: () => {
    const userData = localStorage.getItem('pharmaGuardUser');
    return userData ? JSON.parse(userData) : null;
  }
};
