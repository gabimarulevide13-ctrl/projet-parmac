// Utilitaires de géolocalisation
const getCurrentLocation = () => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('La géolocalisation n\'est pas supportée'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
      },
      (error) => {
        // Position par défaut à Abidjan si géolocalisation échoue
        console.warn('Géolocalisation échouée, utilisation position par défaut');
        resolve({
          latitude: 5.3364, // Abidjan
          longitude: -3.9889,
          accuracy: null
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  });
};

// Calcul de distance entre deux points (formule de Haversine)
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Rayon de la Terre en km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const toRad = (value) => {
  return value * Math.PI / 180;
};

// Vérifier si une pharmacie est ouverte selon ses horaires
const checkIfOpen = (hours) => {
  if (hours === '24h/24') return true;
  
  const now = new Date();
  const currentHour = now.getHours();
  
  // Extraction simple des heures d'ouverture
  const match = hours.match(/(\d+)h-(\d+)h/);
  if (match) {
    const openHour = parseInt(match[1]);
    const closeHour = parseInt(match[2]);
    return currentHour >= openHour && currentHour < closeHour;
  }
  
  return false; // Par défaut fermé si format non reconnu
};

// Ouvrir dans Google Maps
const openInMaps = (latitude, longitude) => {
  const url = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;
  window.open(url, '_blank');
};