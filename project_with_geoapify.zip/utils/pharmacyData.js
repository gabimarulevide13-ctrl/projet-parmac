
const API_KEY = "437ed6b9447d4093b64a689dd08bb6b5";

// --- NOUVELLE FONCTION : API Geoapify ---
export async function fetchPharmaciesNearby(latitude, longitude, radius = 5000) {
  const url = `https://api.geoapify.com/v2/places?categories=healthcare.pharmacy&filter=circle:${longitude},${latitude},${radius}&limit=5&apiKey=${API_KEY}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("Erreur API Geoapify");
    }
    const data = await response.json();

    // Convertir le format Geoapify en format de l'app
    return data.features.map((f, index) => ({
      id: index + 1,
      name: f.properties.name || "Pharmacie inconnue",
      address: f.properties.address_line2 || f.properties.address_line1 || "Adresse inconnue",
      city: f.properties.city || "",
      district: f.properties.suburb || "",
      latitude: f.geometry.coordinates[1],
      longitude: f.geometry.coordinates[0],
      phone: f.properties.phone || "",
      hours: "Non précisé",
      isOpen: true,
      services: [],
      distance: f.properties.distance || null
    }));
  } catch (error) {
    console.error("Impossible d'utiliser l'API Geoapify :", error);
    return generateMockPharmacies(); // fallback sur les données locales
  }
}

// --- DONNÉES LOCALES SIMULÉES (inchangées) ---
export function generateMockPharmacies() {
  const pharmacies = [
    // données originales (non modifiées)
  ];
  return pharmacies.map(pharmacy => ({
    ...pharmacy,
    distance: Math.random() * 50 + 0.5
  }));
}

export function filterPharmacies(pharmacies, filters, userLocation) {
  return pharmacies.filter(pharmacy => {
    if (filters.open24h && !pharmacy.hours.includes('24h')) return false;
    if (filters.nightService && !pharmacy.services.includes('Garde')) return false;
    if (filters.hasStock && Math.random() < 0.3) return false;
    if (userLocation && pharmacy.distance > filters.searchRadius) return false;
    return true;
  });
}

export function searchPharmacies(pharmacies, query) {
  if (!query.trim()) return pharmacies;
  const searchTerm = query.toLowerCase();
  return pharmacies.filter(pharmacy =>
    pharmacy.name.toLowerCase().includes(searchTerm) ||
    pharmacy.address.toLowerCase().includes(searchTerm) ||
    pharmacy.city.toLowerCase().includes(searchTerm) ||
    pharmacy.district.toLowerCase().includes(searchTerm)
  );
}
