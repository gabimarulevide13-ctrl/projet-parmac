# Design System - PharmaGuard

## Palette de Couleurs Médicale

### Couleurs Principales
- **Primary (Vert médical)** : `#16a085` - Confiance, santé, sérénité
- **Secondary (Vert clair)** : `#48c9b0` - Fraîcheur, vitalité
- **Accent (Bleu action)** : `#3498db` - Actions, interactions, liens

### Couleurs Fonctionnelles
- **Success** : `#27ae60` - Confirmations, statuts positifs
- **Warning** : `#f39c12` - Alertes, attention
- **Error** : `#e74c3c` - Erreurs, statuts négatifs

### Couleurs Neutres
- **Background** : `#f8fffe` - Arrière-plan principal
- **Surface** : `#ffffff` - Cartes, modals
- **Text Primary** : `#2c3e50` - Texte principal
- **Text Secondary** : `#7f8c8d` - Texte secondaire
- **Border** : `#ecf0f1` - Bordures, séparateurs

## Typographie

### Police Principale
- **Inter** - Police moderne, lisible, professionnelle
- Poids : 300, 400, 500, 600, 700

### Hiérarchie
- **H1** : 2.5rem (40px) - Bold - Titres principaux
- **H2** : 2rem (32px) - Bold - Sous-titres
- **H3** : 1.5rem (24px) - Semibold - Sections
- **Body** : 1rem (16px) - Regular - Texte principal
- **Small** : 0.875rem (14px) - Medium - Texte secondaire

## Composants UI

### Boutons
- **Primary** : Arrondis (16px), ombre douce, effet hover
- **Secondary** : Bordure, fond transparent, transition
- **Accent** : Bleu, actions importantes

### Cartes
- **Radius** : 24px (rounded-3xl)
- **Shadow** : Douce, subtile
- **Padding** : 32px (p-8)
- **Hover** : Élévation, translation

### Icônes Médicales
- **Cross** : Pharmacie, santé
- **Heart-pulse** : So
# Partial content, replace this line and continue implementing the file.