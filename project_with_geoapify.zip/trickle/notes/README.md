# PharmaGuard - Application de Localisation des Pharmacies de Garde

## Description
PharmaGuard est une application web permettant de localiser rapidement les pharmacies de garde ouvertes en temps réel en Côte d'Ivoire. L'application offre une interface utilisateur intuitive avec géolocalisation, filtres de recherche et tableau de bord administrateur.

## Fonctionnalités Principales

### Pour les Utilisateurs
- **Géolocalisation automatique** : Détection de la position de l'utilisateur
- **Carte interactive** : Visualisation des pharmacies sur une carte
- **Filtres avancés** : Recherche par horaires (24h/24, service de nuit), stock disponible, rayon de recherche
- **Informations détaillées** : Adresse, téléphone, horaires, services disponibles
- **Navigation GPS** : Redirection vers Google Maps pour l'itinéraire
- **Interface responsive** : Compatible mobile et desktop

### Pour les Administrateurs
- **Tableau de bord** : Vue d'ensemble des pharmacies
- **Gestion CRUD** : Création, modification, suppression des pharmacies
- **Statistiques** : Nombre total, pharmacies 24h/24, statut d'ouverture
- **Interface d'administration** dédiée

## Base de Données des Pharmacies

L'application contient maintenant une base de données complète avec **20 pharmacies** réparties dans les principales villes de Côte d'Ivoire :

### Abidjan (10 pharmacies)
- **Plateau** : Pharmacie de la Paix, Pharmacie Centrale
- **Cocody** : Pharmacie Nouvelle, Pharmacie Riviera
- **Adjamé** : Pharmacie du Centre, Pharmacie Liberté
- **Marcory** : Pharmacie Moderne, Pharmacie Zone 4
- **Treichville** : Pharmacie Treichville
- **Yopougon** : Pharmacie Yopougon

### Autres Villes (10 pharmacies)
- **Bouaké** : Pharmacie Centrale Bouaké, Pharmacie Koko
- **Yamoussoukro** : Pharmacie de la Capitale
- **Daloa** : Pharmacie Daloa Centre
- **Korhogo** : Pharmacie du Nord
- **San-Pédro** : Pharmacie du Port
- **Man** : Pharmacie des Montagnes
- **Gagnoa** : Pharmacie Gagnoa
- **Abengourou** : Pharmacie de l'Est
- **Divo** : Pharmacie Divo

## Architecture Technique

### Frontend
- **React 18** : Framework JavaScript
- **TailwindCSS** : Framework CSS utilitaire
- **Lucide Icons** : Bibliothèque d'icônes
- **Architecture MPA** : Multi-page application pour de meilleures performances

### Structure des Fichiers
```
/
├── index.html              # Page principale
├── admin.html             # Tableau de bord admin
├── app.js                 # Application principale
├── admin-app.js           # Application admin
├── components/            # Composants React
│   ├── Header.js
│   ├── AuthForm.js
│   ├── PharmacyCard.js
│   ├── MapView.js
│   ├── FilterPanel.js
│   ├── SearchBar.js
│   ├── AdminHeader.js
│   └── PharmacyTable.js
└── utils/                 # Utilitaires
    ├── auth.js
    ├── geolocation.js
    └── pharmacyData.js
```

## Installation et Déploiement
1. Cloner le projet
2. Ouvrir `index.html` dans un navigateur
3. Pour l'administration : accéder à `admin.html`

## Évolutions Futures
- Intégration Google Maps API complète
- Connexion à la base de données Trickle
- API REST pour la gestion des données
- Authentification JWT
- Notifications push
- Application mobile React Native

## Dernières Mises à Jour
- **Base de données étendue** : 20 pharmacies couvrant toute la Côte d'Ivoire
- **Correction des erreurs** : Résolution des problèmes de chargement des composants
- **Interface améliorée** : Meilleure organisation des scripts et composants