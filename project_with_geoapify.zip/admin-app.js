function AdminApp() {
  try {
    const [pharmacies, setPharmacies] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      // Charger les données des pharmacies
      setTimeout(() => {
        const mockData = generateMockPharmacies();
        setPharmacies(mockData);
        setLoading(false);
      }, 1000);
    }, []);

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--primary-color)] mx-auto mb-4"></div>
            <p>Chargement du tableau de bord...</p>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen" data-name="admin-app" data-file="admin-app.js">
        <AdminHeader />
        
        <main className="container mx-auto px-4 py-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-[var(--text-primary)] mb-2">
              Tableau de Bord Administrateur
            </h1>
            <p className="text-[var(--text-secondary)]">
              Gestion des pharmacies de garde en Côte d'Ivoire
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Total Pharmacies</p>
                  <p className="text-2xl font-bold text-[var(--text-primary)]">{pharmacies.length}</p>
                </div>
                <div className="w-12 h-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
                  <div className="icon-building text-white text-xl"></div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Ouvertes 24h/24</p>
                  <p className="text-2xl font-bold text-[var(--text-primary)]">
                    {pharmacies.filter(p => p.hours === '24h/24').length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-[var(--accent-color)] rounded-lg flex items-center justify-center">
                  <div className="icon-clock text-white text-xl"></div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Actuellement ouvertes</p>
                  <p className="text-2xl font-bold text-[var(--text-primary)]">
                    {pharmacies.filter(p => p.isOpen).length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-[var(--success-color)] rounded-lg flex items-center justify-center">
                  <div className="icon-check-circle text-white text-xl"></div>
                </div>
              </div>
            </div>
          </div>

          <PharmacyTable pharmacies={pharmacies} setPharmacies={setPharmacies} />
        </main>
      </div>
    );
  } catch (error) {
    console.error('AdminApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('admin-root'));
root.render(<AdminApp />);